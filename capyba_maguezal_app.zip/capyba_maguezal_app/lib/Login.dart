import 'package:capyba_maguezal_app/Registration.dart';
import 'package:capyba_maguezal_app/WelcomeManguezal.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';


class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {


  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _verSenha = false;
  final _firebaseAuth = FirebaseAuth.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Login'),),
      body: Center(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextFormField(
                  controller: _emailController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                      label: Text('email'), hintText: 'nome@gmail.com'),
                ),
                TextFormField(
                  controller: _passwordController,
                  keyboardType: TextInputType.visiblePassword,
                  obscureText: !_verSenha,
                  decoration: InputDecoration(
                    label: Text('senha'), hintText: 'Digite a sua senha',
                    suffixIcon: IconButton(
                      icon: Icon(
                          _verSenha ? Icons.visibility_off_outlined : Icons
                              .visibility_outlined),
                      onPressed: () {
                        setState(() {
                          _verSenha = !_verSenha;
                        });
                      },
                    ),
                  ),
                ),
                SizedBox(height: 20),
                ElevatedButton(onPressed: () {
                    login();
                }, child: Text('Entrar'),
                ),
                TextButton(onPressed: () {
                  Navigator.push(
                      context, MaterialPageRoute(builder: (context) => Registration(),
                    ),
                  );
                }, child: Text('Criar Conta'))
              ],
            ),
          ),
        ),
      );
  }

  login() async {
    try {
      UserCredential userCredential = await _firebaseAuth
          .signInWithEmailAndPassword(
          email: _emailController.text, password: _passwordController.text);
      if (userCredential != null) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const WelcomeManguezal(),
          ),
        );
      }
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found') {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Usuário não encontrado'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }else if (e.code == 'wrong-password'){
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Senha inválida'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
    }
  }
}



