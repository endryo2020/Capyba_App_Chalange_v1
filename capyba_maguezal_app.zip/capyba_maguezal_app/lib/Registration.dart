import 'package:capyba_maguezal_app/CheckUser.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
//import 'package:flutter_pw_validator/flutter_pw_validator.dart';

class Registration extends StatefulWidget {
  const Registration({Key? key}) : super(key: key);

  @override
  State<Registration> createState() => _RegistrationState();
}

class _RegistrationState extends State<Registration> {

  final _nomeController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _verSenha = false;
  final _firebaseAuth = FirebaseAuth.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Registration'),
      ),
      body: ListView(
        padding: EdgeInsets.all(12),
        children: [
          TextFormField(
            controller: _nomeController,
            decoration: InputDecoration(
            label: Text('Nome completo'),
            ),
          ),
          TextFormField(
            controller: _emailController,
            keyboardType: TextInputType.emailAddress,
            decoration: InputDecoration(
            label: Text('Digite seu e-mail'),
            ),
          ),
          TextFormField(
            controller: _passwordController,
            keyboardType: TextInputType.visiblePassword,
            obscureText: !_verSenha,
            decoration: InputDecoration(
              label: Text('senha'), hintText: 'Digite a sua senha',
              suffixIcon: IconButton(
                icon: Icon(
                    _verSenha ? Icons.visibility_off_outlined : Icons
                        .visibility_outlined),
                onPressed: () {
                  setState(() {
                    _verSenha = !_verSenha;
                  });
                },
              ),
            ),
          ),
          SizedBox(height: 20),
          ElevatedButton(onPressed: () {
            cadastrar();
          }, child: Text('Registrar'),
          ),
        ],
      ),
    );
  }
  cadastrar() async {
    try{
      UserCredential userCredential = await _firebaseAuth
          .createUserWithEmailAndPassword(
          email: _emailController.text, password: _passwordController.text);

      if (userCredential != null){
        userCredential.user!.updateDisplayName(_nomeController.text);
        Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(
              builder: (context) => CheckUser(),
            ),
                (route) => false);
      }
    }on FirebaseAuthException catch (e){
      if(e.code == 'weak-password'){
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Crie uma senha mais forte'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }else if(e.code == 'email-already-in-use'){
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Email já cadastrado'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
    }
  }
}
