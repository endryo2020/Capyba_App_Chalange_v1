import 'package:capyba_maguezal_app/CheckUser.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class WelcomeManguezal extends StatefulWidget {
  const WelcomeManguezal({Key? key}) : super(key: key);

  @override
  State<WelcomeManguezal> createState() => _WelcomeManguezalState();
}

class _WelcomeManguezalState extends State<WelcomeManguezal> {

  final _firebaseAuth = FirebaseAuth.instance;
  String nome='';  //Falta incluir no registro
  String email='';

  @override
  initState() {
    pegarUsuario();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            UserAccountsDrawerHeader(
                accountName: Text(nome), //Falta incluir no registro
                accountEmail: Text(email),
            ),
            ListTile(
              dense: true,
              title: Text('Sair'),
              trailing: Icon(Icons.exit_to_app),
              onTap: (){
                sair();
              },
            ),
          ],
        ),
      ),
      appBar: AppBar(
        centerTitle: true,
        title: Text('Welcome to the Manguezal'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(email, textAlign: TextAlign.center),
          Text('Bem vindo ao nosso Manguezal', textAlign: TextAlign.center),
        ],
      ),
    );
  }

  pegarUsuario() async {
    User? usuario = await _firebaseAuth.currentUser;
    if(usuario != null){
      setState(() {
        email = usuario.email.toString();
      });


    }
  }

  sair() async{
    await _firebaseAuth.signOut().then((user) =>
      Navigator.pushReplacement(context, MaterialPageRoute(
        builder:(context) => CheckUser(),
        ),
      )
    );
  }

}

